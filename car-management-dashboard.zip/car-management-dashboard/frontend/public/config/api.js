const api = {
    host: "localhost",
    port: 4000
}