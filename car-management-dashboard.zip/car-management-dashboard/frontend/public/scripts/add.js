const app = new AddCarApp();
app.init();