// LOAD APP
const app = new DashboardApp();
app.init();