const app = new EditCarApp();
app.init();