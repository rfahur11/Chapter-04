# Challenge 4 Dashboard manajemen

### Deskripsi Project
APlikasi dashboard menggunakan express js
cara setup :
cd frontend 
npm install
npm start

cd backend
npm install
konfigurasi postgre di file config.json
sequelize db:create
sequelize db:migrate
atur cloudinary pada cloudinary.js
cd backend
npm start

### ERD
![Alt text](/car-management-dashboard/readme-files/db-diagram.png "a title")
![Alt text](/car-management-dashboard/readme-files/db-diagram-2.png "a title")